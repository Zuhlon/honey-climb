'use client'

import { useState, useEffect, useCallback, useRef } from 'react'

// Client types for incoming dance messages
const CLIENT_TYPES = [
  { name: '🌻 сосед.полянка', emoji: '🌸' },
  { name: '🌳 сосед.лес', emoji: '🦌' },
  { name: '🏡 сосед.улей', emoji: '🏠' }
]

interface Client {
  id: number
  type: typeof CLIENT_TYPES[0]
}

// Styles object for Apple Arcade design
const styles = {
  // CSS custom properties
  ':root': {
    '--bg-primary': '#0a0a0f',
    '--bg-secondary': '#1a1a2e',
    '--accent-gold': '#FFD700',
    '--accent-orange': '#FFA500',
    '--accent-purple': '#8B5CF6',
    '--danger': '#EF4444',
    '--success': '#10B981',
    '--glass-bg': 'rgba(255, 255, 255, 0.05)',
    '--glass-border': 'rgba(255, 255, 255, 0.1)',
  }
}

export default function BeeCallCenter() {
  // Game state
  const [balance, setBalance] = useState(5)
  const [operators, setOperators] = useState(3)
  const [maxOperators] = useState(12)
  const [clientQueue, setClientQueue] = useState<Client[]>([])
  const [hornetActive, setHornetActive] = useState(false)
  const [hornetDuration, setHornetDuration] = useState(0)
  const [capturedOperators, setCapturedOperators] = useState(0)
  const [achievementUnlocked, setAchievementUnlocked] = useState(false)
  
  // UI state
  const [balanceAnimation, setBalanceAnimation] = useState(false)
  const [hireAnimation, setHireAnimation] = useState(false)
  const [answerAnimation, setAnswerAnimation] = useState(false)
  const [newClientAnimation, setNewClientAnimation] = useState<number | null>(null)
  const [hornetAnimation, setHornetAnimation] = useState(false)
  
  const clientIdRef = useRef(0)
  const gameLoopRef = useRef<NodeJS.Timeout | null>(null)
  const hornetLoopRef = useRef<NodeJS.Timeout | null>(null)

  const freeOperators = operators - capturedOperators

  // Spawn a new client
  const spawnClient = useCallback(() => {
    const newClient: Client = {
      id: ++clientIdRef.current,
      type: CLIENT_TYPES[Math.floor(Math.random() * CLIENT_TYPES.length)]
    }
    setClientQueue(prev => [...prev, newClient])
    setNewClientAnimation(newClient.id)
    setTimeout(() => setNewClientAnimation(null), 500)
  }, [])

  // Trigger hornet attack
  const triggerHornet = useCallback(() => {
    if (hornetActive) return
    
    const currentFreeOps = operators - capturedOperators
    if (currentFreeOps <= 0) return
    
    setHornetActive(true)
    setHornetDuration(8)
    setHornetAnimation(true)
    
    // Capture 1-2 operators
    const captureAmount = Math.min(currentFreeOps, Math.floor(Math.random() * 2) + 1)
    setCapturedOperators(prev => prev + captureAmount)
    
    // Hornet duration countdown
    hornetLoopRef.current = setInterval(() => {
      setHornetDuration(prev => {
        if (prev <= 1) {
          setHornetActive(false)
          setHornetAnimation(false)
          if (hornetLoopRef.current) clearInterval(hornetLoopRef.current)
          return 0
        }
        return prev - 1
      })
    }, 1000)
  }, [hornetActive, operators, capturedOperators])

  // Game tick
  useEffect(() => {
    gameLoopRef.current = setInterval(() => {
      // Spawn client with 55% chance
      if (Math.random() < 0.55) {
        spawnClient()
      }
      
      // Trigger hornet with 20% chance (if not already active)
      if (!hornetActive && Math.random() < 0.2) {
        triggerHornet()
      }
    }, 2000)

    return () => {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current)
      if (hornetLoopRef.current) clearInterval(hornetLoopRef.current)
    }
  }, [spawnClient, triggerHornet, hornetActive])

  // Check achievement
  useEffect(() => {
    if (balance === operators && balance > 0 && !achievementUnlocked) {
      setAchievementUnlocked(true)
    }
  }, [balance, operators, achievementUnlocked])

  // Animate balance change
  const animateBalance = useCallback(() => {
    setBalanceAnimation(true)
    setTimeout(() => setBalanceAnimation(false), 300)
  }, [])

  // Hire bee action
  const hireBee = useCallback(() => {
    if (balance >= 1 && operators < maxOperators) {
      setHireAnimation(true)
      setBalance(prev => prev - 1)
      setOperators(prev => Math.min(prev + 1, maxOperators))
      animateBalance()
      setTimeout(() => setHireAnimation(false), 200)
    }
  }, [balance, operators, maxOperators, animateBalance])

  // Answer call action
  const answerCall = useCallback(() => {
    if (freeOperators <= 0 || clientQueue.length === 0) return
    
    setAnswerAnimation(true)
    setClientQueue(prev => prev.slice(1))
    
    let earning = 1.0
    if (hornetActive && Math.random() < 0.4) earning = 0.5
    
    setBalance(prev => Math.round((prev + earning) * 10) / 10)
    animateBalance()
    
    // Chance to rescue captured operator
    if (capturedOperators > 0 && Math.random() < 0.3) {
      setCapturedOperators(prev => Math.max(0, prev - 1))
    }
    
    setTimeout(() => setAnswerAnimation(false), 200)
  }, [freeOperators, clientQueue, hornetActive, capturedOperators, animateBalance])

  return (
    <>
      {/* Inject keyframe animations */}
      <style jsx global>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-4px); }
        }
        
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-3px) rotate(-2deg); }
          75% { transform: translateX(3px) rotate(2deg); }
        }
        
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.8; transform: scale(1.05); }
        }
        
        @keyframes popIn {
          0% { transform: scale(0.8); opacity: 0; }
          50% { transform: scale(1.1); }
          100% { transform: scale(1); opacity: 1; }
        }
        
        @keyframes slideIn {
          0% { transform: translateX(50px); opacity: 0; }
          100% { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes glow {
          0%, 100% { box-shadow: 0 0 20px rgba(255, 215, 0, 0.3); }
          50% { box-shadow: 0 0 40px rgba(255, 215, 0, 0.6); }
        }
        
        @keyframes hornetAlert {
          0%, 100% { 
            box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4);
          }
          50% { 
            box-shadow: 0 0 20px 5px rgba(239, 68, 68, 0.6);
          }
        }
        
        @keyframes hexagonFloat {
          0% { transform: translateY(0) rotate(0deg); }
          100% { transform: translateY(-20px) rotate(15deg); }
        }
        
        @keyframes achievementGlow {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        
        .bee-float {
          animation: float 2s ease-in-out infinite;
        }
        
        .captured-shake {
          animation: shake 0.5s ease-in-out infinite;
        }
        
        .hornet-pulse {
          animation: pulse 1s ease-in-out infinite;
        }
        
        .pop-in {
          animation: popIn 0.3s ease-out;
        }
        
        .slide-in {
          animation: slideIn 0.4s ease-out;
        }
        
        .achievement-glow {
          background: linear-gradient(90deg, #FFD700, #FFA500, #FFD700);
          background-size: 200% 200%;
          animation: achievementGlow 2s ease infinite;
        }
        
        .hornet-alert-border {
          animation: hornetAlert 1s ease-in-out infinite;
        }
        
        /* Custom scrollbar */
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
          height: 4px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.05);
          border-radius: 10px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 215, 0, 0.3);
          border-radius: 10px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 215, 0, 0.5);
        }
        
        /* Touch optimization */
        .touch-button {
          -webkit-tap-highlight-color: transparent;
          touch-action: manipulation;
          user-select: none;
        }
        
        .touch-button:active {
          transform: scale(0.95);
        }
        
        /* Safe area support */
        .safe-bottom {
          padding-bottom: max(16px, env(safe-area-inset-bottom));
        }
        
        .safe-top {
          padding-top: max(12px, env(safe-area-inset-top));
        }
      `}</style>
      
      {/* Main container */}
      <div style={{
        minHeight: '100dvh',
        background: 'linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #16213e 100%)',
        color: 'white',
        fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "SF Pro Display", "Segoe UI", Roboto, sans-serif',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        position: 'relative',
      }}>
        {/* Decorative hexagon patterns */}
        <div style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          overflow: 'hidden',
          pointerEvents: 'none',
          zIndex: 0,
        }}>
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              style={{
                position: 'absolute',
                width: 80 + Math.random() * 60,
                height: 80 + Math.random() * 60,
                background: 'rgba(255, 215, 0, 0.03)',
                borderRadius: '12px',
                transform: `rotate(${45 + i * 30}deg)`,
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
              }}
            />
          ))}
        </div>
        
        {/* Header */}
        <header className="safe-top" style={{
          padding: '16px 20px',
          background: 'rgba(255, 255, 255, 0.03)',
          backdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
          position: 'relative',
          zIndex: 10,
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px',
            marginBottom: '12px',
          }}>
            <span style={{ fontSize: '28px' }}>🐝</span>
            <h1 style={{
              fontSize: '22px',
              fontWeight: 700,
              background: 'linear-gradient(135deg, #FFD700, #FFA500)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              letterSpacing: '-0.5px',
            }}>
              HIVE CALL CENTER
            </h1>
          </div>
          
          {/* Stats bar */}
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            gap: '24px',
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 16px',
              background: 'rgba(255, 215, 0, 0.1)',
              borderRadius: '20px',
              border: '1px solid rgba(255, 215, 0, 0.2)',
            }}>
              <span style={{ fontSize: '18px' }}>⭐</span>
              <span style={{ 
                fontSize: '18px', 
                fontWeight: 600,
                color: '#FFD700',
                transition: 'transform 0.3s ease',
                transform: balanceAnimation ? 'scale(1.2)' : 'scale(1)',
              }}>
                {balance}
              </span>
            </div>
            
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 16px',
              background: 'rgba(139, 92, 246, 0.1)',
              borderRadius: '20px',
              border: '1px solid rgba(139, 92, 246, 0.2)',
            }}>
              <span style={{ fontSize: '18px' }}>📞</span>
              <span style={{ 
                fontSize: '18px', 
                fontWeight: 600,
                color: '#8B5CF6',
              }}>
                {clientQueue.length}
              </span>
            </div>
          </div>
        </header>
        
        {/* Main content area */}
        <main style={{
          flex: 1,
          overflow: 'auto',
          padding: '16px',
          display: 'flex',
          flexDirection: 'column',
          gap: '16px',
          position: 'relative',
          zIndex: 5,
        }}>
          {/* Operators grid */}
          <section style={{
            background: 'rgba(255, 255, 255, 0.04)',
            borderRadius: '24px',
            padding: '20px',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            backdropFilter: 'blur(10px)',
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '16px',
            }}>
              <h2 style={{
                fontSize: '16px',
                fontWeight: 600,
                color: 'rgba(255, 255, 255, 0.9)',
              }}>
                🐝 Операторы
              </h2>
              <span style={{
                fontSize: '14px',
                color: 'rgba(255, 255, 255, 0.5)',
              }}>
                {freeOperators}/{operators} активны
              </span>
            </div>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(4, 1fr)',
              gap: '12px',
            }}>
                {/* Free operators */}
                {[...Array(freeOperators)].map((_, i) => (
                  <div
                    key={`free-${i}`}
                    className="bee-float"
                    style={{
                      aspectRatio: '1',
                      background: 'linear-gradient(135deg, rgba(255, 215, 0, 0.2), rgba(255, 165, 0, 0.1))',
                      borderRadius: '16px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '32px',
                      border: '2px solid rgba(255, 215, 0, 0.3)',
                      boxShadow: '0 4px 12px rgba(255, 215, 0, 0.2)',
                    }}
                  >
                    🐝
                  </div>
                ))}
                
                {/* Captured operators */}
                {[...Array(capturedOperators)].map((_, i) => (
                  <div
                    key={`captured-${i}`}
                    className="captured-shake"
                    style={{
                      aspectRatio: '1',
                      background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.3), rgba(239, 68, 68, 0.1))',
                      borderRadius: '16px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '32px',
                      border: '2px solid rgba(239, 68, 68, 0.4)',
                      boxShadow: '0 4px 12px rgba(239, 68, 68, 0.2)',
                    }}
                  >
                    🕷️
                  </div>
                ))}
                
                {/* Empty slots */}
                {[...Array(maxOperators - operators)].map((_, i) => (
                  <div
                    key={`empty-${i}`}
                    style={{
                      aspectRatio: '1',
                      background: 'rgba(255, 255, 255, 0.03)',
                      borderRadius: '16px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '24px',
                      border: '2px dashed rgba(255, 255, 255, 0.1)',
                    }}
                  >
                    ➕
                  </div>
                ))}
              </div>
          </section>
          
          {/* Incoming queue */}
          <section style={{
            background: 'rgba(255, 255, 255, 0.04)',
            borderRadius: '24px',
            padding: '20px',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            backdropFilter: 'blur(10px)',
          }}>
            <h2 style={{
              fontSize: '16px',
              fontWeight: 600,
              color: 'rgba(255, 255, 255, 0.9)',
              marginBottom: '12px',
            }}>
              📨 Входящие танцы
            </h2>
            
            <div 
              className="custom-scrollbar"
              style={{
                display: 'flex',
                gap: '10px',
                overflowX: 'auto',
                padding: '4px 0',
                minHeight: '56px',
              }}
            >
              {clientQueue.length === 0 ? (
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flex: 1,
                  color: 'rgba(255, 255, 255, 0.3)',
                  fontSize: '14px',
                }}>
                  Ожидание звонков...
                </div>
              ) : (
                clientQueue.map((client, index) => (
                  <div
                    key={client.id}
                    className={newClientAnimation === client.id ? 'slide-in' : ''}
                    style={{
                      flexShrink: 0,
                      padding: '12px 16px',
                      background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.2), rgba(139, 92, 246, 0.1))',
                      borderRadius: '16px',
                      border: '1px solid rgba(139, 92, 246, 0.3)',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      fontSize: '14px',
                      whiteSpace: 'nowrap',
                      animationDelay: `${index * 0.1}s`,
                    }}
                  >
                    <span style={{ fontSize: '20px' }}>{client.type.emoji}</span>
                    <span style={{ color: 'rgba(255, 255, 255, 0.8)' }}>
                      {client.type.name}
                    </span>
                  </div>
                ))
              )}
            </div>
          </section>
          
          {/* Hornet alert */}
          {hornetActive && (
            <section 
              className="hornet-alert-border"
              style={{
                background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(239, 68, 68, 0.1))',
                borderRadius: '24px',
                padding: '16px 20px',
                border: '2px solid rgba(239, 68, 68, 0.5)',
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
              }}
            >
              <div 
                className="hornet-pulse"
                style={{
                  width: '48px',
                  height: '48px',
                  background: 'rgba(239, 68, 68, 0.3)',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '28px',
                }}
              >
                🦅
              </div>
              <div style={{ flex: 1 }}>
                <h3 style={{
                  fontSize: '16px',
                  fontWeight: 600,
                  color: '#EF4444',
                  marginBottom: '4px',
                }}>
                  ⚠️ Шершень атакует!
                </h3>
                <p style={{
                  fontSize: '13px',
                  color: 'rgba(255, 255, 255, 0.6)',
                }}>
                  Осталось {hornetDuration}с • Поймано пчёл: {capturedOperators}
                </p>
              </div>
            </section>
          )}
          
          {/* Achievement section */}
          <section style={{
            background: achievementUnlocked 
              ? 'linear-gradient(135deg, rgba(255, 215, 0, 0.15), rgba(255, 165, 0, 0.1))'
              : 'rgba(255, 255, 255, 0.04)',
            borderRadius: '24px',
            padding: '20px',
            border: achievementUnlocked 
              ? '2px solid rgba(255, 215, 0, 0.4)'
              : '1px solid rgba(255, 255, 255, 0.08)',
            backdropFilter: 'blur(10px)',
            transition: 'all 0.3s ease',
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              marginBottom: '12px',
            }}>
              <span style={{ fontSize: '24px' }}>🏆</span>
              <h2 style={{
                fontSize: '16px',
                fontWeight: 600,
                color: achievementUnlocked ? '#FFD700' : 'rgba(255, 255, 255, 0.9)',
              }}>
                Достижение
              </h2>
              {achievementUnlocked && (
                <span style={{
                  marginLeft: 'auto',
                  padding: '4px 12px',
                  background: 'rgba(16, 185, 129, 0.2)',
                  borderRadius: '12px',
                  fontSize: '12px',
                  color: '#10B981',
                  fontWeight: 600,
                }}>
                  ✓ Разблокировано
                </span>
              )}
            </div>
            
            <p style={{
              fontSize: '14px',
              color: achievementUnlocked ? 'rgba(255, 215, 0, 0.9)' : 'rgba(255, 255, 255, 0.5)',
              marginBottom: '12px',
            }}>
              Баланс = Операторы
            </p>
            
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
            }}>
              <div style={{
                flex: 1,
                height: '8px',
                background: 'rgba(255, 255, 255, 0.1)',
                borderRadius: '4px',
                overflow: 'hidden',
              }}>
                <div style={{
                  width: `${Math.min(100, (balance / operators) * 100)}%`,
                  height: '100%',
                  background: achievementUnlocked 
                    ? 'linear-gradient(90deg, #FFD700, #FFA500)'
                    : 'linear-gradient(90deg, #8B5CF6, #6366F1)',
                  borderRadius: '4px',
                  transition: 'width 0.3s ease',
                }} />
              </div>
              <span style={{
                fontSize: '12px',
                color: 'rgba(255, 255, 255, 0.5)',
                minWidth: '60px',
                textAlign: 'right',
              }}>
                {balance} / {operators}
              </span>
            </div>
          </section>
        </main>
        
        {/* Bottom action buttons */}
        <footer 
          className="safe-bottom"
          style={{
            padding: '16px 20px',
            background: 'rgba(0, 0, 0, 0.3)',
            backdropFilter: 'blur(20px)',
            borderTop: '1px solid rgba(255, 255, 255, 0.08)',
            position: 'relative',
            zIndex: 10,
          }}
        >
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '12px',
          }}>
            {/* Hire button */}
            <button
              onClick={hireBee}
              disabled={balance < 1 || operators >= maxOperators}
              className="touch-button"
              style={{
                minHeight: '72px',
                padding: '16px',
                background: balance >= 1 && operators < maxOperators
                  ? 'linear-gradient(135deg, rgba(139, 92, 246, 0.3), rgba(139, 92, 246, 0.15))'
                  : 'rgba(255, 255, 255, 0.05)',
                border: balance >= 1 && operators < maxOperators
                  ? '2px solid rgba(139, 92, 246, 0.5)'
                  : '2px solid rgba(255, 255, 255, 0.1)',
                borderRadius: '20px',
                cursor: balance >= 1 && operators < maxOperators ? 'pointer' : 'not-allowed',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '4px',
                transition: 'all 0.2s ease',
                transform: hireAnimation ? 'scale(0.95)' : 'scale(1)',
                opacity: balance >= 1 && operators < maxOperators ? 1 : 0.5,
              }}
            >
              <span style={{ fontSize: '28px' }}>🐝</span>
              <span style={{ 
                fontSize: '15px', 
                fontWeight: 600,
                color: balance >= 1 && operators < maxOperators ? '#8B5CF6' : 'rgba(255, 255, 255, 0.4)',
              }}>
                НАНЯТЬ
              </span>
              <span style={{ 
                fontSize: '13px',
                color: 'rgba(255, 255, 255, 0.5)',
              }}>
                -1 ⭐
              </span>
            </button>
            
            {/* Answer button */}
            <button
              onClick={answerCall}
              disabled={freeOperators <= 0 || clientQueue.length === 0}
              className="touch-button"
              style={{
                minHeight: '72px',
                padding: '16px',
                background: freeOperators > 0 && clientQueue.length > 0
                  ? 'linear-gradient(135deg, rgba(255, 215, 0, 0.3), rgba(255, 165, 0, 0.15))'
                  : 'rgba(255, 255, 255, 0.05)',
                border: freeOperators > 0 && clientQueue.length > 0
                  ? '2px solid rgba(255, 215, 0, 0.5)'
                  : '2px solid rgba(255, 255, 255, 0.1)',
                borderRadius: '20px',
                cursor: freeOperators > 0 && clientQueue.length > 0 ? 'pointer' : 'not-allowed',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '4px',
                transition: 'all 0.2s ease',
                transform: answerAnimation ? 'scale(0.95)' : 'scale(1)',
                opacity: freeOperators > 0 && clientQueue.length > 0 ? 1 : 0.5,
              }}
            >
              <span style={{ fontSize: '28px' }}>📞</span>
              <span style={{ 
                fontSize: '15px', 
                fontWeight: 600,
                color: freeOperators > 0 && clientQueue.length > 0 ? '#FFD700' : 'rgba(255, 255, 255, 0.4)',
              }}>
                ОТВЕТИТЬ
              </span>
              <span style={{ 
                fontSize: '13px',
                color: 'rgba(255, 255, 255, 0.5)',
              }}>
                +1 ⭐
              </span>
            </button>
          </div>
          
          {/* Game info */}
          <div style={{
            marginTop: '12px',
            textAlign: 'center',
            fontSize: '12px',
            color: 'rgba(255, 255, 255, 0.3)',
          }}>
            Нажимайте кнопки для управления колл-центром
          </div>
        </footer>
      </div>
    </>
  )
}
